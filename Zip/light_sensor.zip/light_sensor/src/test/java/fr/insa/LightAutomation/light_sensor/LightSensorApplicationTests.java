package fr.insa.LightAutomation.light_sensor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LightSensorApplicationTests {

	@Test
	void contextLoads() {
	}

}
