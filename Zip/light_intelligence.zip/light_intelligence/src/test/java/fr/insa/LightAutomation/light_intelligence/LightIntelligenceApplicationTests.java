package fr.insa.LightAutomation.light_intelligence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LightIntelligenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
