package fr.insa.LightAutomation.presence_sensor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PresenceSensorApplicationTests {

	@Test
	void contextLoads() {
	}

}
