package fr.insa.LightAutomation.light_actuator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LightActuatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(LightActuatorApplication.class, args);
	}

}
