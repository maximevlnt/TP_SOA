package fr.insa.LightAutomation.light_actuator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LightActuatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
